<?php 

	require_once "modelo/usuarios.php";

    class UsuariosControlador {
		private $usuarios;

	  	public function __CONSTRUCT(){
				$this->usuarios = new Usuarios();
	  	}

	  	public function Registar(){

	  		$u = new Usuarios();
	  		$u->setLogin($_POST['login']);
	  		$u->setNombre($_POST['nombre']);
	  		$u->setPassword($_POST['password']);
	  		$this->usuarios->Insertar($u);

	  		// Creamos la variable de sesión para el usuario
        	$_SESSION['login'] = $_POST['login'];
        	$_SESSION['nombre'] = $_POST['nombre'];


	  	} 	
	  	public function Cerrar (){
	  		session_destroy();
	  		header("location: index.php");
	  	}

		public function Login(){
			$log = $_POST['login'];
			$pass = $_POST['password'];
			$usuario = $this->usuarios->Consultar($log,$pass);
			$correcto = false;
			$login=$usuario->getLogin();
			$password=$usuario->getPassword();
			$nombre=$usuario->getNombre();
			if(!is_null($login) && !is_null($password)){
				$correcto = true;
				//Creamos la variable de sesion para el usuario
				$_SESSION['login']= $login;
				$_SESSION{'nombre'}= $nombre;
			}
			
			echo json_encode(array(
				'correcto' => $correcto,
			));
		}
		
	}