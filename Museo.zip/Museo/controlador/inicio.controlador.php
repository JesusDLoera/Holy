<?php
	require_once "modelo/objeto.php";
	
	class InicioControlador{
		private $modelo;
		public function __CONSTRUCT(){
			$this->modelo = new Objeto();
		}
		public function Inicio(){

			require_once "vista\Edecanes.php";
		}

	}