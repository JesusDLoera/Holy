<?php 

	require_once "modelo/objeto.php";

    class ObjetoControlador {
    	private $modelo;

	  	public function __CONSTRUCT(){
	  		$this->modelo = new Objeto();
	  	}
		  public function Ingresar (){
			require_once "vista/Menu.php";
		}
	  	

	  
	}