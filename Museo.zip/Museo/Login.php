<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <form method="post" action="Login.php">
    <link rel="stylesheet" href="C:\xampp\htdocs\Edecanes\estilos.css">
    </head>
    <form action="Login.php" method="post"></form>
  <body>
    <div class="contenedor">
      <div class="login">
        <article class="fondo">
          <img src="img/L.jpg" alt="User">
          <h3>Inicio de sesión</h3>
          <form class="" action="index.html" method="post">
            <input class="inp" type="text" placeholder="Usuario" value=""><br>
            <input class="inp" type="password" placeholder="Contraseña" value=""><br>
            <input class="boton" type="submit" name="inicio" value="Iniciar Sesión">
          </form>
        </article>
      </div>

    </div>
  </body>
</html>
