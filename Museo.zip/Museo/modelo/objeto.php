<?php 

class Objeto {
    private $pdo;
    private $idEdecanes;
    private $Nombre;
    private $Telefono;
    private $MedCintura;
    private $MedCadera;
    private $MedBusto;
    private $Estatura;
    private $NumCalsado;
    private $TallaBlusa;


	public function __CONSTRUCT(){
		$this->pdo =BasedeDatos::Conectar();
    }
     /**
     * Get the value of idEdecanes
     */ 
    public function getidEdecanes()
    {
        return $this->idEdecanes;
    }

    /**
     * Set the value of idEdecanes
     *
     * @return  self
     */ 
    public function setidEdecanes($idEdecanes)
    {
        $this->idEdecanes = $idEdecanes;

        return $this;
    }

    /**
     * Get the value of Nombre
     */ 
    public function getNombre()
    {
        return $this->Nombre;
    }

    /**
     * Set the value of Nombre
     *
     * @return  self
     */ 
    public function setNombre($Nombre)
    {
        $this->Nombre = $Nombre;

        return $this;
    }

    /**
     * Get the value of Telefono
     */ 
    public function getTelefono()
    {
        return $this->Telefono;
    }

    /**
     * Set the value of Telefono
     *
     * @return  self
     */ 
    public function setTelefono(Telefono)
    {
        $this->Telefono = Telefono;

        return $this;
    }

    /**
     * Get the value of MedCintura
     */ 
    public function getMedCintura()
    {
        return $this->MedCintura;
    }

    /**
     * Set the value of MedCintura
     *
     * @return  self
     */ 
    public function setMedCintura($MedCintura)
    {
        $this->MedCintura = $MedCintura;

        return $this;
    }

    /**
     * Get the value of MedCadera
     */ 
    public function getMedCadera()
    {
        return $this->MedCadera;
    }

    /**
     * Set the value of MedCadera
     *
     * @return  self
     */ 
    public function setMedCadera($MedCadera)
    {
        $this->MedCadera = $MedCadera;

        return $this;
    }

    /**
     * Get the value of MedBusto
     */ 
    public function getMedBusto()
    {
        return $this->MedBusto;
    }

    /**
     * Set the value of MedBusto
     *
     * @return  self
     */ 
    public function setMedBusto($MedBusto)
    {
        $this->MedBusto = $MedBusto;

        return $this;
    }
    
    /**
     * Get the value of Estatura
     */ 
    public function getEstatura()
    {
        return $this->Estatura;
    }

    /**
     * Set the value of Estatura
     *
     * @return  self
     */ 
    public function setEstatura($Estatura)
    {
        $this->Estatura = $Estatura;

        return $this;
    }
    public function getNumCalsado()
    {
        return $this->NumCalsado;
    }

    /**
     * Set the value of NumCalsado
     *
     * @return  self
     */ 
    public function setNumCalsado($NumCalsado)
    {
        $this->NumCalsado = $NumCalsado;

        return $this;
    }
    public function getTallaBlusa()
    {
        return $this->TallaBlusa;
    }

    /**
     * Set the value of TallaBlusa
     *
     * @return  self
     */ 
    public function setTallaBlusa($TallaBlusa)
    {
        $this->NumCalsado = $NumCalsado;

        return $this;
    }
    public function getTallaPantalon()
    {
        return $this->TallaPantalon;
    }

    /**
     * Set the value of TallaPantalon
     *
     * @return  self
     */ 
    public function setTallaBlusa($TallaPantalon)
    {
        $this->TallaPantalon = $TallaPantalon;

        return $this;
    }
	public function Listar(){
		try{
			$sql = "SELECT * FROM objetarte";
			$consulta =$this->pdo->prepare($sql);
			$consulta->execute();
			//fetch all trae todos los resultados
			return $consulta->fetchALL(PDO::FETCH_OBJ);

		}catch(Exception $e){
			die($e->getMessage());
		}
    }
    
    public function test($id){
		try{
			$sql = "SELECT * FROM objetarte where idEdecanes=".$id;
            $consulta =$this->pdo->prepare($sql);
			$consulta->execute();
			
            //fetch all trae todos los resultados
            
			return $consulta->fetch(PDO::FETCH_OBJ);

		}catch(Exception $e){
			die($e->getMessage());
		}
    }
    

	public function Obtener($id){
		try{
            
			$sql = "SELECT * FROM objetarte where id=?";
			$consulta =$this->pdo->prepare($sql);
			$consulta->execute(array($id));
			//fetch all trae todos los resultados
			$r=$consulta->fetch(PDO::FETCH_OBJ);
			$p=new Producto();
			$p->setidEdecanes($r->idEdecanes);
			$p->setNombre($r->Nombre);
			$p->setTelefono($r->Telefono);
			$p->setMedCintura($r->MedCintura);
			$p->setMedCadera($r->MedCadera);
            $p->setMedBusto($r->MedBusto);
            $p->setEstatura($r->Estatura);

			return $p;

		}catch(Exception $e){
			die($e->getMessage());
		}
	}


	public function Insertar(Objeto $p){
		try{
			$sql = "INSERT into objetarte (Nombre,Telefono,MedCintura,MedCadera,MedBusto, Estatura) values (?,?,?,?,?,?);";
			$this->pdo->prepare($sql)
				->execute(array(
					$p->getNombre(),
					$p->getTelefono(),
					$p->getMedCintura(),
					$p->getMedCadera(),
                    $p->getMedBusto(),
                    $p->getEstatura()
				));
		}catch(Exception $e){
            die($e->getMessage());
            print("No se hizo la insercion");
		}		
	}

	public function Actualizar(Objeto $p){
		try{
			$sql = "UPDATE objetarte SET 
                Nombre=?,
                Telefono=?,
                MedCintura=?,
                MedCadera=?,
                MedBusto=?,
                Estatura=?
				WHERE idEdecanes = ?; 
			 ";
			 $this->pdo->prepare($sql)
				->execute(array(
					$p->getNombre(),
					$p->getTelefono(),
					$p->getMedCintura(),
					$p->getMedCadera(),
                    $p->getMedBusto(),
                    $p->getEstatura(),
                    $p->getidEdecanes()

				));
		}catch(Exception $e){
			die($e->getMessage());
		}		
	}

	public function Eliminar($id){
		try{
			$sql = "DELETE FROM objetarte WHERE idEdecanes = ?;";
			 $this->pdo->prepare($sql)
				->execute(array($id));
		}catch(Exception $e){
			die($e->getMessage());
		}		
    }
    public function Administrador(){
        try{
            $sql = "SELECT * FROM bitacora";
            $consulta =$this->pdo->prepare($sql);
            $consulta->execute();
            //fetch all trae todos los resultados
            return $consulta->fetchALL(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }
    }



    public function GetObjById($id) {
        try{
            $sql = "SELECT * FROM objetarte WHERE idEdecanes = $id;";
            $consulta =$this->pdo->prepare($sql);
            $consulta->execute();
            //fetch all trae todos los resultados
            return $consulta->fetchALL(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }
    }
		

}