<?php 

class Usuarios {
	private $pdo;
	private $login;
	private $nombre;
	private $password;

	public function __CONSTRUCT(){
		$this->pdo =BasedeDatos::Conectar();
	}

	public function getLogin(){
		return $this->login;
	}

	public function setLogin($login){
		$this->login = $login;
	}

	public function getNombre(){
		return $this->nombre;
	}
	public function setNombre($nombre){
		$this->nombre = $nombre;
	}

	public function getPassword(){
		return $this->password;
	}

	public function setPassword($password){
		$this->password = $password;
	}

	//Metodos para acceder a la base de datos
	public function Consultar($password, $login){
		try{
			$sql = "select * from usuarios where login = ? and password = ?;";
			$res = $this->pdo->prepare($sql);
			$res-> execute(array(
				$login,
				$password
			));
			$us = $res->fetch(PDO::FETCH_ASSOC);
			$uasuario =  new Usuarios();
			$uasuario->setLogin($us['login']);
			$uasuario->setNombre($us['nombre']);
			$uasuario->setPassword($us['password']);
			
			return $uasuario;
		}catch(Exception $e){
			die($e->getMessage());
		}
	}
	public function Listar(){
		try{
			$sql = "SELECT * FROM usuarios";
			$consulta =$this->pdo->prepare($sql);
			$consulta->execute();
			//fetch all trae todos los resultados
			return $consulta->fetchALL(PDO::FETCH_OBJ);

		}catch(Exception $e){
			die($e->getMessage());
		}
	}
}	