<?php 
    if (!isset($_SESSION)) { 
    	session_start(); 
    }
	require_once "modelo/conexion.php";

if (!isset($_GET['c'])){
		require_once "controlador/inicio.controlador.php";
		$controlador = new InicioControlador();
		call_user_func(array($controlador,"Inicio"));
	}else {
		$controlador = $_GET['c'];
		require_once "controlador/$controlador.controlador.php";

		$controlador = ucwords($controlador)."Controlador";

		$controlador = new $controlador;
		
		$accion = isset($_GET['a']) ? $_GET['a'] : "Inicio";
		if(isset($_GET['h'])){
			call_user_func(array($controlador,$accion), $_GET['h']);
		} else {
			call_user_func(array($controlador,$accion));
		}
	}
?>