<!doctype html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Menu</title>
<link rel="stylesheet" href="libreria\estiloss.css">
</head>
<body>
	
	<div id="titulo">
		<p id="header">Agencia Ves</p>	
	</div>

	<header>
		
		<div class="contenedor" id="uno">
			<img class="icon" src="pictures/icon1.png">
			<p class="texto">Edecanes</p>
		</div>

		<div class="contenedor" id="dos">
			<img class="icon" src="pictures/icon2.png">
			<p class="texto">Marcas</p>
		</div>

		<div class="contenedor" id="tres">
			<img class="icon" src="pictures/icon3.png">
			<p class="texto">Eventos</p>
		</div>

	</header>
	

	

</body>
</html>