<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="libreria\estilos.css">
    <script src="libreria/vendor/jquery/js/jquery-3.3.1.min.js"></script>
    <script scr="libreria/vendor/jquery/js/popper.min.js"></script>
    </head>
  <body>
    <div class="contenedor">
      <div class="login">
        <article class="fondo">
          <img src="img/L.jpg" alt="User">
          <h3>Inicio de sesión</h3>
          <form id="ingresar" method="post">
            <input  id="loginIngresar" class="inp" type="text" placeholder="Usuario"><br>
            <input id="passwordIngresar" name="passwordIngresar"class="inp" type="password" placeholder="Contraseña"><br>
            <input id="btningresar" name="btningresar" class="boton" type="button" name="inicio">
          </form>
        </article>
      </div>

    </div>
    <script>
		$('#ingresar').on('click', '#btningresar', function(e){
        var flogin = $("#loginIngresa").val();
        var fpassword = $("#passwordIngresa").val();

      $.post("?c=usuarios&a=Login",{
        login: flogin,
        password: fpassword,
      },
      function (response){
        console.log(response);
        var obj = JSON.parse(response);
        var correcto = obj.correcto;
        if(correcto){
          location.href="?c=objeto&a=Ingresar";
        }
        else{
          location.href="#";
          alert("Login incorrecto");
       }
      }
      )

        });
		</script>
    
  </body>
</html>
